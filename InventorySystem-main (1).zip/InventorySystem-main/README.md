# InventorySystem

This is a basic inventory managemt system with


Steps for running this inventory management system

### Step1:
Clone the repository using ```git clone```
```terminaloutput
git clone https://github.com/Dhyey17/InventorySystem.git
```

### Step 2:
Install the requirements from the requirements file.
```terminaloutput
pip install -r requirements.txt
```

### Step 4:
Setup your account on <a href="supabase.com">Supabase</a>

### Step 5:
Create a **.env** file with the required variables


### Step 6:
Run app.py
```terminaloutput
python app.py
```